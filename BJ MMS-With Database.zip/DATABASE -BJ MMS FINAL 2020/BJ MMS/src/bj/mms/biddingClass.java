
package bj.mms;

public class biddingClass {
 private double Member1=0;
 private double Member2=0;
  private double Member3=0;
   private double Member4=0;
 biddingClass()
    {
        this.Member1=0;
 this.Member2=0;
  this.Member3=0;
   this.Member4=0;
}
 double sum=0,average=0;
    public double getMember1() {
        return Member1;
    }

    public void setMember1(double Member1) {
        this.Member1 = Member1;
    }

    public double getMember2() {
        return Member2;
    }

    public void setMember2(double Member2) {
        this.Member2 = Member2;
    }

    public double getMember3() {
        return Member3;
    }

    public void setMember3(double Member3) {
        this.Member3 = Member3;
    }

    public double getMember4() {
        return Member4;
    }

    public void setMember4(double Member4) {
        this.Member4 = Member4;
    }
    
String Rate="";
 public void biddingClass(double mem1,double mem2,double mem3,double mem4)
 {
     this.Member1=mem1;
     this.Member2=mem2;
     this.Member3=mem3;
     this.Member4=mem4;
     this.sum=mem1+mem2+mem3+mem4;
     this.average=sum/4;
 }
 
 
}