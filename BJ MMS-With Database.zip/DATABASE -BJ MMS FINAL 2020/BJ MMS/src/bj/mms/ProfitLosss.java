
package bj.mms;


public class ProfitLosss extends SupplyIntakeClass  {
    
    int i=1;

    ProfitLosss(double val1,double val2,double val3,double val4)
    {
     if(val1>=val2 || val3>=4)
     {
      i=1;   
     }
     else if(val1<=val2 || val3<=val4)
     {
        i=0;
    }
}

}
