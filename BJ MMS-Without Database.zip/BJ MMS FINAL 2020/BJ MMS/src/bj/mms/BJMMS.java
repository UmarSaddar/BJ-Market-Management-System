
package bj.mms;

/**
 *
 * @author Lenovo
 */
public class BJMMS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   LoginChoice a=new LoginChoice();
   
   a.setVisible(true);
   
    }
    
}
