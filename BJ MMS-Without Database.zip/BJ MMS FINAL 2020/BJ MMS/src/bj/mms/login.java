
package bj.mms;

import javax.swing.JOptionPane;


public class login {
    
    private String username="admin";
    private String password="admin";

    public login(){
        this.password="admin";
        this.username="admin";
    }
    public login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    int i=0;
       LoginAdmin a=new LoginAdmin();
    public void logincheck(String name,String pass ){
        login l=new login();
        if (l.getUsername().equals(name)&& l.getPassword().equals(pass)){
            
            JOptionPane.showMessageDialog(null,"Access Grainted");
         i=0;   
        }
        else if (!this.username.equals(name)&& this.password.equals(pass))
        {
           
            JOptionPane.showMessageDialog(null,"Access Denied \n Invalid UserName");
         
            a.setVisible(true);
        i=1;
        }
        else if (l.getUsername().equals(name)&& !this.password.equals(pass))
        {
        i=1;   
            JOptionPane.showMessageDialog(null,"Access Denied \n Invalid Password");
        a.setVisible(true);
        }
         else if (!this.username.equals(name)&& !this.password.equals(pass))
        {
        i=1;   
            JOptionPane.showMessageDialog(null,"Access Denied \n Invalid Username and Password");
        a.setVisible(true);
        }
        else
         {
        i=1;
             JOptionPane.showMessageDialog(null,"Enter Valid Credentials");
         a.setVisible(true);
         } 
        
    };
}

