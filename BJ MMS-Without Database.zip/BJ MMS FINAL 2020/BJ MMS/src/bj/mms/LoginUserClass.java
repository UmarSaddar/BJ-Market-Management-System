
package bj.mms;

import javax.swing.JOptionPane;


public class LoginUserClass {
     private String username="user";
    private String password="user";

    public LoginUserClass(){
        this.password="user";
        this.username="user";
    }
    public LoginUserClass(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }
int i=1;
    public void setPassword(String password) {
        this.password = password;
    }
        public void logincheck(String name,String pass ){
    
            LoginUserClass l=new LoginUserClass();
        if (l.getUsername().equals(name)&& l.getPassword().equals(pass)){
            
            JOptionPane.showMessageDialog(null,"Access Grainted");
   i=1;
        }
        else if (!this.username.equals(name)&& this.password.equals(pass))
        {
           
            JOptionPane.showMessageDialog(null,"Access Denied \n Invalid UserName");
        i=0;
        
        }
        else if (l.getUsername().equals(name)&& !this.password.equals(pass))
        {
           
            JOptionPane.showMessageDialog(null,"Access Denied \n Invalid Password");
        i=0;
        }
         else if (!this.username.equals(name)&& !this.password.equals(pass))
        {
           
            JOptionPane.showMessageDialog(null,"Access Denied \n Invalid Username and Password");
        i=0;
        }
        else
         {
             JOptionPane.showMessageDialog(null,"Enter Valid Credentials");
        i=0;
         } 
        
    };

}
