/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bj.mms;

/**
 *
 * @author Lenovo
 */
public class CalculationClass {
    double result=0;
    public void sub(double val1,double val2)
    {
        result=val1-val2;
    }
}
