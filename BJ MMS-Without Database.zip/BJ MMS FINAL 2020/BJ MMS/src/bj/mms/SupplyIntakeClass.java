/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bj.mms;

/**
 *
 * @author Lenovo
 */
public class SupplyIntakeClass extends biddingClass{
    private double intake=0,supply=0;
  public  double remaining=0;

    SupplyIntakeClass()
            {
                this.intake=0;
                this.remaining=0;
                this.average=0;
                this.supply=0;
                this.sum=0;
            }
    public double getIntake() {
        return intake;
    }

    public void setIntake(double intake) {
        this.intake = intake;
    }

    public double getSupply() {
        return supply;
    }

    public void setSupply(double supply) {
        this.supply = supply;
    }

    public double getRemaining() {
        return remaining;
    }

    public void setRemaining(double remaining) {
        this.remaining = remaining;
    }

    public double getSum() {
        return sum;
    }

    public void setSum(double sum) {
        this.sum = sum;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }
    
    SupplyIntakeClass(double INTAKE,double SUPPLY)
    {
       this.intake=INTAKE;
       this.supply=SUPPLY;
       this.remaining=INTAKE-SUPPLY;
        
    }
    
}
